# hitch.ai

## Installation
1. Download this zip
2. [How to install chrome extension](https://webkul.com/blog/how-to-install-the-unpacked-extension-in-chrome/)