# hitch.ai plugin

## Installation
1. Download this the chrome extension
    - [Click here to download chrome extension](https://github.com/hacksnextdoor/hitch.ai/raw/master/dist.zip)
2. Install the chrome extension to your browser 
    - [How to install chrome extension](https://webkul.com/blog/how-to-install-the-unpacked-extension-in-chrome/)
3. Login into your [Tinder account](https://tinder.com)
4. Let us find you some matches!
